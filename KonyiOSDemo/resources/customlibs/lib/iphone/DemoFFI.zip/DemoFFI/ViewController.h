//
//  ViewController.h
//  DemoApp
//
//  Created by Jayant Tiwari on 05/05/22.
//  Copyright © 2022 Fiserv. All rights reserved.
//

#import <UIKit/UIKit.h>



@interface ViewController : UIViewController

+ (id)generateInstance;

-(void)loadZelleSDK;

@end
