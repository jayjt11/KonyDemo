//
//  ViewController.m
//  DemoApp
//
//  Created by Jayant Tiwari on 05/05/22.
//  Copyright © 2022 Fiserv. All rights reserved.
//

#import "ViewController.h"
#import <ZelleSDK/ZelleSDK.h>

@interface ViewController ()

@end

@implementation ViewController

static ViewController* gInstance = nil;

+(id)generateInstance
{
    //static BarcodeReader *gInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        gInstance = [[self alloc] init];
    });
    return gInstance;
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
}


-(void)loadZelleSDK {
   
    NSLog(@"Welcome to Kony");
    Zelle *zelle = [[Zelle alloc] initWithApplicationName:@"" baseUrl:@"" institutionId:@"" product:@"" ssoKey:@"" title:@"" parameters:@{@"key1" :@"value1", @"key2" :@"value2"}];

    Bridge *bridge = [[Bridge alloc]initWithConfig:zelle viewController:self];

    CGRect zelleFrame = CGRectMake(0,0, self.view.frame.size.width, self.view.frame.size.height);
    BridgeView *bridgeView = [bridge viewWithFrame:zelleFrame];
    [self.view addSubview:bridgeView];
}

@end
